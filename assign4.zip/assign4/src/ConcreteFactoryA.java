class ConcreteFactoryA implements Factory {
    @Override
    public String create() {
        return "Product A";
    }
}
