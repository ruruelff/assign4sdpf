interface Observer {
    void update(String data);
}