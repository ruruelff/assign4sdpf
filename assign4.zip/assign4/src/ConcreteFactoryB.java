class ConcreteFactoryB implements Factory {
    @Override
    public String create() {
        return "Product B";
    }
}
