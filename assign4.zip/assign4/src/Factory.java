interface Factory {
    String create();
}
