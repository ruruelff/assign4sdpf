import java.util.ArrayList;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        // Observer Pattern usage
        Subject subject = new Subject();
        Observer observer1 = new ConcreteObserver("Observer 1");
        Observer observer2 = new ConcreteObserver("Observer 2");

        subject.attach(observer1);
        subject.attach(observer2);

        subject.notify("Some data has changed.");

        // Factory Pattern usage
        Factory factoryA = new ConcreteFactoryA();
        String productA = factoryA.create();

        Factory factoryB = new ConcreteFactoryB();
        String productB = factoryB.create();

        System.out.println(productA); // Output: Product A
        System.out.println(productB); // Output: Product B
    }
}